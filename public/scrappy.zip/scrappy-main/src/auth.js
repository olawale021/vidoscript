import { exec } from 'child_process';
import crypto from 'crypto';
import fs from 'fs/promises';
import os from 'os';
import path from 'path';
import { promisify } from 'util';

/**
 * Public key for license verification (safe to distribute with source code)
 * The corresponding private key is kept secret and used only for license generation
 */
const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0pKtC+6vlCFx+LsrtBr2
DuIPFn8Ex9rjtURL4NV9e9fLCMO8Qe1/nBitOGXcsuSwygyu8Hwi63Q1BJ1IMklk
puVjSXZCNm61oaSBsawqwhqqy+NMVRMBlyZ16SCUczKxgVEeaeBCr/KSP3jw+l2r
TLEXrNet3GMzHBab++dBkh+ZIrZWcpDPWI1rHXuS++PoATxsdMk+w7FssDsxIHKT
q+kTeh0+D1a4TGw+qAdvpEDNVTyZEmt79QNx7Q+Qze8w7Q5xCUQgWb9X1+3LPPVS
giAGccqTy2pZgDr1wwPBo/asSQqEaV7AFe8GU3ch1T31B5wtVk5lZ7B8AG773u0t
9QIDAQAB
-----END PUBLIC KEY-----`;

/**
 * License and binding file paths
 */
const LICENSE_FILE = path.join(process.cwd(), '.license');
const BINDINGS_FILE = path.join(process.cwd(), '.license-bindings.json');

const execAsync = promisify(exec);

/**
 * Get machine fingerprint (unique identifier for this PC)
 */
async function getMachineFingerprint() {
  try {
    const hostname = os.hostname();
    const platform = os.platform();
    const arch = os.arch();
    
    // Get MAC address of primary network interface
    let macAddress = '';
    const networkInterfaces = os.networkInterfaces();
    
    for (const [name, interfaces] of Object.entries(networkInterfaces)) {
      if (name !== 'lo' && interfaces) {
        for (const iface of interfaces) {
          if (!iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
            macAddress = iface.mac;
            break;
          }
        }
        if (macAddress) break;
      }
    }
    
    // Create a unique fingerprint
    const fingerprint = crypto
      .createHash('sha256')
      .update(`${hostname}-${platform}-${arch}-${macAddress}`)
      .digest('hex')
      .substring(0, 16);
    
    return {
      fingerprint,
      hostname,
      platform,
      arch,
      macAddress: macAddress || 'unknown'
    };
    
  } catch (error) {
    throw new Error('Failed to generate machine fingerprint');
  }
}

/**
 * Get current public IP address
 */
async function getPublicIP() {
  try {
    // Try multiple services in case one is down
    const services = [
      'curl -s https://api.ipify.org',
      'curl -s https://icanhazip.com',
      'curl -s https://ipecho.net/plain'
    ];
    
    for (const service of services) {
      try {
        const { stdout } = await execAsync(service);
        const ip = stdout.trim();
        if (ip && /^\d+\.\d+\.\d+\.\d+$/.test(ip)) {
          return ip;
        }
      } catch (err) {
        continue;
      }
    }
    
    return 'unknown';
  } catch (error) {
    return 'unknown';
  }
}

/**
 * Load license bindings from file
 */
async function loadBindings() {
  try {
    const data = await fs.readFile(BINDINGS_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    return {};
  }
}

/**
 * Save license bindings to file
 */
async function saveBindings(bindings) {
  try {
    await fs.writeFile(BINDINGS_FILE, JSON.stringify(bindings, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Verify a cryptographically signed license
 */
export function isValidLicense(signedLicense) {
  try {
    // Parse the signed license: base64(licenseData + '.' + signature)
    const decoded = Buffer.from(signedLicense, 'base64').toString('utf-8');
    
    // Find the JSON end pattern "}." to properly separate license data from signature
    const jsonEndPattern = '}.';
    const jsonEndIndex = decoded.indexOf(jsonEndPattern);
    
    if (jsonEndIndex === -1) {
      return false;
    }
    
    const licenseData = decoded.substring(0, jsonEndIndex + 1); // Include the closing brace
    const signature = decoded.substring(jsonEndIndex + 2); // Skip the dot
    
    if (!licenseData || !signature) {
      return false;
    }
    
    // Verify the signature
    const verifier = crypto.createVerify('SHA256');
    verifier.update(licenseData);
    verifier.end();
    
    const isValid = verifier.verify(PUBLIC_KEY, signature, 'base64');
    
    if (!isValid) {
      return false;
    }
    
    // Parse license data
    const license = JSON.parse(licenseData);
    
    // Check if license is expired
    if (license.expiresAt && new Date() > new Date(license.expiresAt)) {
      return false;
    }
    
    // Check license type
    if (license.type !== 'PREMIUM') {
      return false;
    }
    
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Extract license information from signed license (for display purposes)
 */
export function parseLicenseInfo(signedLicense) {
  try {
    const decoded = Buffer.from(signedLicense, 'base64').toString('utf-8');
    
    // Find the JSON end pattern "}." to properly separate license data from signature
    const jsonEndPattern = '}.';
    const jsonEndIndex = decoded.indexOf(jsonEndPattern);
    
    if (jsonEndIndex === -1) {
      return null;
    }
    
    const licenseData = decoded.substring(0, jsonEndIndex + 1); // Include the closing brace
    const license = JSON.parse(licenseData);
    return license;
  } catch (error) {
    return null;
  }
}

/**
 * Generate a cryptographically signed license (requires private key - admin only)
 * This function is for demonstration - the actual implementation should be kept separate
 */
export function generateLicenseKey() {
  console.log('🚫 License generation requires private key (not included in source distribution)');
  console.log('📞 Contact administrator to generate new licenses');
  console.log('');
  console.log('🔧 To generate licenses, use the secure license generator tool');
  console.log('   with your private key (kept separate from this source code)');
  
  return null;
}

/**
 * Save license key to file
 */
export async function saveLicense(licenseKey) {
  try {
    await fs.writeFile(LICENSE_FILE, licenseKey.trim());
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Load license key from file
 */
export async function loadLicense() {
  try {
    const license = await fs.readFile(LICENSE_FILE, 'utf-8');
    return license.trim();
  } catch (error) {
    return null;
  }
}

/**
 * Check if user is authorized to use the tool
 */
export async function checkAuthorization() {
  const machineInfo = await getMachineFingerprint();
  const currentIP = await getPublicIP();
  const bindings = await loadBindings();
  
  // Check environment variable first
  const envLicense = process.env.EMAIL_PROVIDER_LICENSE;
  if (envLicense && isValidLicense(envLicense)) {
    const binding = bindings[envLicense];
    if (binding) {
      // Check if license is bound to this machine
      if (binding.fingerprint !== machineInfo.fingerprint) {
        throw new Error(`License ${envLicense} is bound to a different machine (${binding.hostname})`);
      }
      // Optionally check IP (commented out as IPs can change)
      // if (binding.ip !== currentIP) {
      //   throw new Error(`License ${envLicense} is bound to a different IP address`);
      // }
    }
    return { authorized: true, source: 'environment', license: envLicense };
  }
  
  // Check license file
  const fileLicense = await loadLicense();
  if (fileLicense && isValidLicense(fileLicense)) {
    const binding = bindings[fileLicense];
    if (binding) {
      // Check if license is bound to this machine
      if (binding.fingerprint !== machineInfo.fingerprint) {
        throw new Error(`License ${fileLicense} is bound to a different machine (${binding.hostname})`);
      }
    }
    return { authorized: true, source: 'file', license: fileLicense };
  }
  
  return { authorized: false, source: null };
}

/**
 * License activation command
 */
export async function activateLicense(licenseKey) {
  if (!licenseKey) {
    throw new Error('License key is required');
  }
  
  if (!isValidLicense(licenseKey)) {
    throw new Error('Invalid license key');
  }
  
  // Get machine and IP information
  const machineInfo = await getMachineFingerprint();
  const currentIP = await getPublicIP();
  
  // Load existing bindings
  const bindings = await loadBindings();
  
  // Check if license is already bound to another machine
  if (bindings[licenseKey]) {
    const existingBinding = bindings[licenseKey];
    if (existingBinding.fingerprint !== machineInfo.fingerprint) {
      throw new Error(
        `License key is already activated on another machine:\n` +
        `  Bound to: ${existingBinding.hostname} (${existingBinding.fingerprint})\n` +
        `  Activated: ${existingBinding.activatedAt}\n` +
        `  Current machine: ${machineInfo.hostname} (${machineInfo.fingerprint})\n\n` +
        `Each license can only be used on one machine.`
      );
    }
  } else {
    // Create new binding
    bindings[licenseKey] = {
      fingerprint: machineInfo.fingerprint,
      hostname: machineInfo.hostname,
      platform: machineInfo.platform,
      macAddress: machineInfo.macAddress,
      ip: currentIP,
      activatedAt: new Date().toISOString(),
      lastUsed: new Date().toISOString()
    };
    
    // Save bindings
    const bindingsSaved = await saveBindings(bindings);
    if (!bindingsSaved) {
      throw new Error('Failed to save license binding');
    }
  }
  
  // Update last used timestamp
  bindings[licenseKey].lastUsed = new Date().toISOString();
  bindings[licenseKey].ip = currentIP; // Update IP in case it changed
  await saveBindings(bindings);
  
  // Save license locally
  const saved = await saveLicense(licenseKey);
  if (!saved) {
    throw new Error('Failed to save license key');
  }
  
  return {
    success: true,
    machineInfo,
    binding: bindings[licenseKey]
  };
}

/**
 * Show license status
 */
export async function getLicenseStatus() {
  try {
    const auth = await checkAuthorization();
    const machineInfo = await getMachineFingerprint();
    const currentIP = await getPublicIP();
    
    if (auth.authorized) {
      const license = auth.license || 
        (auth.source === 'environment' ? process.env.EMAIL_PROVIDER_LICENSE : await loadLicense());
      
      const bindings = await loadBindings();
      const binding = bindings[license];
      
      return {
        status: 'active',
        license: license,
        source: auth.source,
        machineInfo: {
          current: machineInfo,
          bound: binding || null
        },
        currentIP,
        binding
      };
    }
    
    return {
      status: 'inactive',
      license: null,
      source: null,
      machineInfo: {
        current: machineInfo,
        bound: null
      },
      currentIP
    };
  } catch (error) {
    return {
      status: 'error',
      error: error.message,
      license: null,
      source: null
    };
  }
}

/**
 * List all license bindings (admin function)
 */
export async function listAllBindings() {
  try {
    const bindings = await loadBindings();
    return bindings;
  } catch (error) {
    return {};
  }
} 