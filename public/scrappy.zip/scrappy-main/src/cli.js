#!/usr/bin/env node

import { program } from 'commander';
import fs from 'fs/promises';
import {
  activateLicense,
  checkAuthorization,
  generateLicenseKey,
  getLicenseStatus,
  listAllBindings
} from './auth.js';
import { detectEmailProvider, getMxRecords } from './emailProviderDetector.js';
import { verifyEmail, verifyEmails } from './emailVerifier.js';
import { EmailProviderPipeline } from './pipeline.js';

/**
 * CLI for Email Provider Detection and Verification
 */
class EmailProviderCLI {
  constructor() {
    this.pipeline = new EmailProviderPipeline();
  }

  /**
   * Check if user is authorized before running commands
   */
  async checkAuth() {
    try {
      const auth = await checkAuthorization();
      if (!auth.authorized) {
        console.log('🔒 Email Provider Detector - Premium Tool');
        console.log('❌ No valid license found.');
        console.log('\n📋 To activate your license:');
        console.log('   node src/cli.js activate <your-license-key>');
        console.log('\n🔑 Or set environment variable:');
        console.log('   export EMAIL_PROVIDER_LICENSE=your-license-key');
        console.log('\n📞 Contact administrator for license key.');
        process.exit(1);
      }
      return auth;
    } catch (error) {
      console.log('🔒 Email Provider Detector - Premium Tool');
      console.log('❌ License validation failed:');
      console.log(`   ${error.message}`);
      console.log('\n📋 Please contact administrator or re-activate your license:');
      console.log('   node src/cli.js activate <your-license-key>');
      process.exit(1);
    }
  }

  /**
   * Setup CLI commands
   */
  setupCommands() {
    program
      .name('email-provider-detector')
      .description('Detect email providers using DNS MX record lookups and verify emails')
      .version('1.0.0');

    // Single email command
    program
      .command('detect <email>')
      .description('Detect provider for a single email address (requires license)')
      .option('-v, --verbose', 'Show detailed information')
      .action(async (email, options) => {
        await this.checkAuth();
        await this.detectSingle(email, options);
      });

    // Email verification commands
    program
      .command('verify <email>')
      .description('Verify a single email address (requires license)')
      .option('-s, --smtp', 'Include SMTP verification (may be slower)')
      .option('-t, --timeout <ms>', 'Verification timeout in milliseconds', '5000')
      .option('-v, --verbose', 'Show detailed verification information')
      .action(async (email, options) => {
        await this.checkAuth();
        await this.verifySingle(email, options);
      });

    program
      .command('verify-list <input>')
      .description('Verify emails from a text file (requires license)')
      .option('-s, --smtp', 'Include SMTP verification (may be slower)')
      .option('-t, --timeout <ms>', 'Verification timeout in milliseconds', '5000')
      .option('-f, --format <format>', 'Output format (csv|json)', 'csv')
      .action(async (input, options) => {
        await this.checkAuth();
        await this.verifyList(input, null, options);
      });

    program
      .command('verify-batch')
      .description('Verify multiple emails from command line arguments (requires license)')
      .option('-o, --output <file>', 'Output file (optional)')
      .option('-s, --smtp', 'Include SMTP verification (may be slower)')
      .option('-t, --timeout <ms>', 'Verification timeout in milliseconds', '5000')
      .option('-f, --format <format>', 'Output format (csv|json)', 'csv')
      .argument('<emails...>', 'Email addresses to verify')
      .action(async (emails, options) => {
        await this.checkAuth();
        await this.verifyBatch(emails, options);
      });

    // License management commands
    program
      .command('activate <license-key>')
      .description('Activate your license key')
      .action(async (licenseKey) => {
        await this.activateLicense(licenseKey);
      });

    program
      .command('status')
      .description('Show license status')
      .action(async () => {
        await this.showLicenseStatus();
      });

    program
      .command('generate-key')
      .description('Generate a new license key (admin only)')
      .action(async () => {
        await this.generateKey();
      });

    program
      .command('list-bindings')
      .description('List all license bindings (admin only)')
      .action(async () => {
        await this.listBindings();
      });

    // Verify and sort by provider (premium feature)
    program
      .command('verify-and-sort <input>')
      .description('Verify emails with SMTP and sort excellent emails by provider (requires license)')
      .option('-c, --concurrency <number>', 'Concurrent verification processes', '15')
      .option('-t, --timeout <ms>', 'Verification timeout in milliseconds', '5000')
      .action(async (input, options) => {
        await this.checkAuth();
        await this.verifyAndSort(input, null, options);
      });

    // Process CSV file
    program
      .command('csv <input> <o>')
      .description('Process CSV file and add email provider column (requires license)')
      .option('-e, --email-column <column>', 'Email column name', 'email')
      .option('-p, --provider-column <column>', 'Provider column name', 'email_provider')
      .option('-c, --concurrency <number>', 'Concurrent lookups', '15')
      .option('-d, --include-details', 'Include detailed fields')
      .option('--single-file', 'Output to single file instead of separate files by provider')
      .option('--no-stats', 'Skip statistics file')
      .action(async (input, output, options) => {
        await this.checkAuth();
        await this.processCSV(input, output, options);
      });

    // Process JSON file
    program
      .command('json <input> <o>')
      .description('Process JSON file and add email provider field (requires license)')
      .option('-e, --email-field <field>', 'Email field name', 'email')
      .option('-p, --provider-field <field>', 'Provider field name', 'email_provider')
      .option('-c, --concurrency <number>', 'Concurrent lookups', '15')
      .option('-d, --include-details', 'Include detailed fields')
      .option('--no-stats', 'Skip statistics file')
      .action(async (input, output, options) => {
        await this.checkAuth();
        await this.processJSON(input, output, options);
      });

    // Process text list
    program
      .command('list <input>')
      .description('Process list of emails from text file (requires license)')
      .option('-s, --smtp', 'Include SMTP verification')
      .option('-t, --timeout <ms>', 'Verification timeout in milliseconds', '5000')
      .option('-f, --format <format>', 'Output format (csv|json)', 'csv')
      .option('--no-stats', 'Skip statistics file')
      .action(async (input, options) => {
        await this.checkAuth();
        await this.processList(input, null, options);
      });

    // Batch process emails from command line
    program
      .command('batch')
      .description('Process multiple emails from command line arguments (requires license)')
      .option('-o, --output <file>', 'Output file (optional)')
      .option('-s, --smtp', 'Include SMTP verification')
      .option('-t, --timeout <ms>', 'Verification timeout in milliseconds', '5000')
      .option('-f, --format <format>', 'Output format (csv|json)', 'csv')
      .argument('<emails...>', 'Email addresses to process')
      .action(async (emails, options) => {
        await this.checkAuth();
        await this.processBatch(emails, options);
      });

    // Interactive mode
    program
      .command('interactive')
      .description('Start interactive mode for email processing (requires license)')
      .action(async () => {
        await this.checkAuth();
        await this.interactiveMode();
      });

    // Generate report
    program
      .command('report <file>')
      .description('Generate detailed report from processed results (requires license)')
      .option('-f, --format <format>', 'Report format (html|text)', 'html')
      .option('-o, --output <file>', 'Output file (optional)')
      .action(async (file, options) => {
        await this.checkAuth();
        await this.generateReport(file, options);
      });

    // Help command
    program
      .addHelpText('after', `
Examples:
  # License management (no license required)
  email-provider-detector activate <your-license-key>
  email-provider-detector status
  
  # Admin functions (no license required)
  email-provider-detector generate-key
  email-provider-detector list-bindings
  
  # All other features require a valid license
  email-provider-detector detect john@gmail.com
  email-provider-detector verify admin@company.com --smtp
  email-provider-detector list examples/email_list.txt
  email-provider-detector verify-list examples/email_list.txt --smtp
  email-provider-detector verify-and-sort examples/email_list.txt
  email-provider-detector csv input.csv output.csv --email-column email
  email-provider-detector interactive

Security Notes:
  • Valid license required for all functionality except license management
  • Each license is bound to one specific machine (identified by hostname, platform, and MAC address)
  • Licenses cannot be transferred between machines without administrative action
  • Machine fingerprints are used to prevent license sharing
      `);
  }

  /**
   * Detect provider for single email
   */
  async detectSingle(email, options) {
    try {
      console.log(`🔍 Analyzing: ${email}\n`);
      
      const result = await detectEmailProvider(email);
      
      console.log('📧 Results:');
      console.log(`   Email: ${result.email}`);
      console.log(`   Domain: ${result.domain || 'N/A'}`);
      console.log(`   Provider: ${result.provider}`);
      
      if (result.success && result.providerCategory) {
        console.log(`   Category: ${result.providerCategory}`);
        if (result.isSecurityService) {
          console.log(`   🛡️  Email Security Service: Yes`);
          console.log(`   Note: This indicates enterprise email security protection`);
        }
        if (result.providerType) {
          console.log(`   Type: ${result.providerType}`);
        }
      }
      
      console.log(`   Status: ${result.success ? '✅ Success' : '❌ Failed'}`);
      
      if (options.verbose && result.success) {
        console.log(`\n🔍 Technical Details:`);
        console.log(`   Primary MX Host: ${result.mxHostname || result.mxRecords?.[0] || 'N/A'}`);
        console.log(`   All MX Records:`);
        result.mxRecords.forEach((mx, index) => {
          console.log(`     ${index + 1}. ${mx}`);
        });
        
        if (result.isSecurityService) {
          console.log(`\n🛡️  Security Service Information:`);
          console.log(`   This email domain uses ${result.provider} for email security.`);
          console.log(`   The actual email hosting may be provided by a different service.`);
          console.log(`   This indicates enterprise-level email protection.`);
        }
      }
      
      if (!result.success && result.error) {
        console.log(`   Error: ${result.error}`);
      }
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Verify single email address
   */
  async verifySingle(email, options) {
    try {
      console.log(`🔍 Verifying: ${email}\n`);
      
      // Get MX records
      let mxRecords = [];
      try {
        const domain = email.split('@')[1];
        mxRecords = await getMxRecords(domain);
      } catch (error) {
        console.log(`⚠️  Warning: Could not get MX records - ${error.message}`);
      }
      
      // Verify email
      const result = await verifyEmail(email, mxRecords, {
        smtpVerify: options.smtp,
        timeout: parseInt(options.timeout)
      });
      
      console.log('📧 Verification Results:');
      console.log(`   Email: ${result.email}`);
      console.log(`   Valid: ${result.valid ? '✅ Yes' : '❌ No'}`);
      console.log(`   Score: ${result.score}/100`);
      console.log(`   Quality: ${result.quality || 'N/A'}`);
      
      if (result.recommendations.length > 0) {
        console.log('   Recommendations:');
        result.recommendations.forEach(rec => {
          console.log(`     • ${rec}`);
        });
      }
      
      if (options.verbose && result.checks) {
        console.log('\n🔍 Detailed Checks:');
        
        if (result.checks.syntax) {
          console.log(`   Syntax: ${result.checks.syntax.valid ? '✅' : '❌'}`);
          if (!result.checks.syntax.valid && result.checks.syntax.issues) {
            result.checks.syntax.issues.forEach(issue => {
              console.log(`     • ${issue}`);
            });
          }
        }
        
        if (result.checks.disposable) {
          console.log(`   Disposable: ${result.checks.disposable.isDisposable ? '❌ Yes' : '✅ No'}`);
        }
        
        if (result.checks.roleAccount) {
          console.log(`   Role Account: ${result.checks.roleAccount.isRole ? '⚠️  Yes' : '✅ No'}`);
        }
        
        if (result.checks.mxRecords) {
          console.log(`   MX Records: ${result.checks.mxRecords.available ? '✅' : '❌'} (${result.checks.mxRecords.count})`);
          if (result.checks.mxRecords.records.length > 0) {
            result.checks.mxRecords.records.forEach((mx, index) => {
              console.log(`     ${index + 1}. ${mx}`);
            });
          }
        }
        
        if (result.checks.smtp) {
          const smtpStatus = result.checks.smtp.valid === true ? '✅' : result.checks.smtp.valid === false ? '❌' : '⚠️';
          console.log(`   SMTP: ${smtpStatus} ${result.checks.smtp.confidence || ''}`);
          if (result.checks.smtp.error) {
            console.log(`     Error: ${result.checks.smtp.error}`);
          }
        }
      }
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Verify emails from a text file
   */
  async verifyList(input, output, options) {
    try {
      console.log(`📖 Reading email list: ${input}`);
      const content = await fs.readFile(input, 'utf-8');
      const emails = content
        .split('\n')
        .map(line => line.trim())
        .filter(line => line && line.includes('@'));
      
      if (emails.length === 0) {
        throw new Error('No valid emails found in file');
      }
      
      console.log(`📧 Found ${emails.length} emails to verify`);
      
      // Verify emails
      const results = await verifyEmails(emails, getMxRecords, {
        concurrency: parseInt(options.concurrency) || 15,
        smtpVerify: options.smtp,
        timeout: parseInt(options.timeout)
      });
      
      // Save results if output specified
      if (output) {
        if (options.format === 'json') {
          await fs.writeFile(output, JSON.stringify(results, null, 2));
        } else {
          // CSV format
          const headers = [
            'email', 'valid', 'score', 'quality', 'syntax_valid', 'is_disposable', 
            'is_role', 'has_mx_records', 'smtp_valid', 'recommendations', 'timestamp'
          ];
          
          const csvData = [
            headers.join(','),
            ...results.map(r => [
              r.email,
              r.valid,
              r.score,
              r.quality || '',
              r.checks?.syntax?.valid || false,
              r.checks?.disposable?.isDisposable || false,
              r.checks?.roleAccount?.isRole || false,
              r.checks?.mxRecords?.available || false,
              r.checks?.smtp?.valid || '',
              r.recommendations?.join('; ') || '',
              r.timestamp
            ].join(','))
          ].join('\n');
          
          await fs.writeFile(output, csvData);
        }
        
        console.log(`\n✅ Results saved to: ${output}`);
      }
      
      // Display summary
      const validCount = results.filter(r => r.valid).length;
      const excellentCount = results.filter(r => r.quality === 'excellent').length;
      const goodCount = results.filter(r => r.quality === 'good').length;
      
      console.log('\n📊 Summary:');
      console.log(`   Total verified: ${results.length}`);
      console.log(`   Valid emails: ${validCount} (${((validCount/results.length)*100).toFixed(1)}%)`);
      console.log(`   Quality breakdown:`);
      console.log(`     Excellent: ${excellentCount}`);
      console.log(`     Good: ${goodCount}`);
      console.log(`     Other: ${results.length - excellentCount - goodCount}`);
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Verify batch of emails from command line
   */
  async verifyBatch(emails, options) {
    try {
      console.log(`🔍 Verifying ${emails.length} emails...`);
      
      // Verify emails
      const results = await verifyEmails(emails, getMxRecords, {
        concurrency: 15,
        smtpVerify: options.smtp,
        timeout: parseInt(options.timeout)
      });
      
      // Save results if output specified
      if (options.output) {
        if (options.format === 'json') {
          await fs.writeFile(options.output, JSON.stringify(results, null, 2));
        } else {
          // CSV format
          const headers = [
            'email', 'valid', 'score', 'quality', 'syntax_valid', 'is_disposable', 
            'is_role', 'has_mx_records', 'smtp_valid', 'recommendations', 'timestamp'
          ];
          
          const csvData = [
            headers.join(','),
            ...results.map(r => [
              r.email,
              r.valid,
              r.score,
              r.quality || '',
              r.checks?.syntax?.valid || false,
              r.checks?.disposable?.isDisposable || false,
              r.checks?.roleAccount?.isRole || false,
              r.checks?.mxRecords?.available || false,
              r.checks?.smtp?.valid || '',
              r.recommendations?.join('; ') || '',
              r.timestamp
            ].join(','))
          ].join('\n');
          
          await fs.writeFile(options.output, csvData);
        }
        
        console.log(`\n✅ Results saved to: ${options.output}`);
      }
      
      // Display results summary
      console.log('\n📧 Results Summary:');
      results.forEach((result, index) => {
        const status = result.valid ? '✅' : '❌';
        const quality = result.quality ? ` (${result.quality})` : '';
        console.log(`${index + 1}. ${result.email} ${status} ${result.score}/100${quality}`);
      });
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Verify emails and sort by provider (premium feature)
   */
  async verifyAndSort(input, output, options) {
    try {
      console.log(`🔍 Premium Email Verification & Provider Sorting`);
      console.log(`📖 Reading email list: ${input}`);
      
      const content = await fs.readFile(input, 'utf-8');
      const emails = content
        .split('\n')
        .map(line => line.trim())
        .filter(line => line && line.includes('@'));
      
      if (emails.length === 0) {
        throw new Error('No valid emails found in file');
      }
      
      // Auto-generate output folder based on input filename
      if (!output) {
        const path = await import('path');
        const inputFilename = path.basename(input, path.extname(input));
        output = `output/${inputFilename}_verified_sorted`;
      }
      
      // Create output directory
      await fs.mkdir(output, { recursive: true });
      
      // Set defaults (can be overridden by CLI options)
      const concurrency = parseInt(options.concurrency) || 15;
      const timeout = parseInt(options.timeout) || 5000;
      const minQuality = 'excellent';
      
      console.log(`📧 Found ${emails.length} emails to verify with SMTP`);
      console.log(`🎯 Filtering for ${minQuality} quality emails only`);
      console.log(`⚡ Concurrency: ${concurrency} | Timeout: ${timeout}ms`);
      console.log(`💾 Results will be saved to: ${output}/\n`);
      console.log(`🚀 IMMEDIATE SAVE: Verified emails will be saved instantly!`);
      
      // Process emails one by one to show progress with provider info
      console.log(`🔍 Verifying and detecting providers...\n`);
      const allResults = [];
      const qualifiedEmails = [];
      const providerGroups = {};
      const createdFiles = new Set(); // Track which files we've created
      
      for (let i = 0; i < emails.length; i++) {
        const email = emails[i];
        const emailNum = i + 1;
        
        try {
          // Verify email
          const verificationResults = await verifyEmails([email], getMxRecords, {
            concurrency: 1,
            smtpVerify: true,
            timeout: timeout
          });
          
          const verifyResult = verificationResults[0];
          allResults.push(verifyResult);
          
          // Detect provider
          let provider = 'Unknown';
          let domain = email.split('@')[1];
          
          try {
            const providerResult = await detectEmailProvider(email);
            provider = providerResult.provider;
            domain = providerResult.domain;
          } catch (error) {
            // Keep default values
          }
          
          // Show progress with quality and provider
          const quality = verifyResult.quality || 'unknown';
          const score = verifyResult.score || 0;
          const status = verifyResult.valid ? '✅' : '❌';
          
          console.log(`[${emailNum}/${emails.length}] ${email}`);
          console.log(`   ${status} Quality: ${quality} (${score}/100) | Provider: ${provider}`);
          
          // Check if email meets excellent quality criteria
          const qualityOrder = { poor: 0, 'not sure': 1, acceptable: 2, good: 3, excellent: 4 };
          const emailQualityLevel = qualityOrder[quality] || 0;
          const minQualityLevel = qualityOrder[minQuality] || 4;
          
          if (verifyResult.valid && emailQualityLevel >= minQualityLevel) {
            const qualifiedEmail = {
              ...verifyResult,
              provider: provider,
              domain: domain
            };
            
            qualifiedEmails.push(qualifiedEmail);
            
            // Group by provider
            if (!providerGroups[provider]) {
              providerGroups[provider] = [];
            }
            providerGroups[provider].push(qualifiedEmail);
            
            // 🚀 IMMEDIATE SAVE: Save email to file right now!
            try {
              const filename = provider.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '') + '.txt';
              const filepath = `${output}/${filename}`;
              
              // Append email to provider file (create if doesn't exist)
              await fs.appendFile(filepath, email + '\n');
              
              // Track that we've created this file
              if (!createdFiles.has(filename)) {
                createdFiles.add(filename);
                console.log(`   📄 Created file: ${filename}`);
              }
              
              console.log(`   ✨ SAVED to ${filename} (${provider})`);
            } catch (error) {
              console.log(`   ⚠️  Error saving to file: ${error.message}`);
              console.log(`   ✨ Added to ${provider} group (in memory)`);
            }
          } else {
            console.log(`   🚫 Excluded (${quality} quality)`);
          }
          
          console.log('');
          
        } catch (error) {
          console.log(`[${emailNum}/${emails.length}] ${email}`);
          console.log(`   ❌ Error: ${error.message}\n`);
        }
      }
      
      console.log(`\n🎯 Found ${qualifiedEmails.length} ${minQuality} quality emails from ${Object.keys(providerGroups).length} providers`);
      
      if (qualifiedEmails.length === 0) {
        console.log(`❌ No emails met the ${minQuality} quality criteria`);
        return;
      }
      
      // Files were already saved immediately during processing!
      console.log(`\n📊 Processing complete - Files already saved!`);
      const savedFiles = [];
      const summary = {};
      
      // Build summary from the groups that were created
      for (const [provider, emailResults] of Object.entries(providerGroups)) {
        const filename = provider.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '') + '.txt';
        savedFiles.push({ provider, filename, count: emailResults.length });
        summary[provider] = emailResults.length;
        
        console.log(`   ✅ ${provider}: ${emailResults.length} emails in ${filename}`);
      }
      
      // Create summary file
      const summaryContent = [
        `# Premium Email Verification & Provider Sorting Results`,
        `Generated: ${new Date().toISOString()}`,
        `Input file: ${input}`,
        `Total emails processed: ${emails.length}`,
        `Quality filter: ${minQuality}`,
        `Qualified emails: ${qualifiedEmails.length}`,
        `Success rate: ${((qualifiedEmails.length/emails.length)*100).toFixed(1)}%`,
        ``,
        `## Provider Distribution:`,
        ...Object.entries(summary)
          .sort(([,a], [,b]) => b - a)
          .map(([provider, count]) => `- ${provider}: ${count} emails`),
        ``,
        `## Files Created:`,
        ...savedFiles.map(f => `- ${f.filename} (${f.count} emails)`)
      ];
      
      await fs.writeFile(`${output}/summary.txt`, summaryContent.join('\n'));
      
      // Display final summary
      console.log(`\n✅ Premium verification complete!`);
      console.log(`🚀 IMMEDIATE SAVE: All verified emails were saved instantly during processing!`);
      console.log(`📊 Final Statistics:`);
      console.log(`   Total processed: ${emails.length}`);
      console.log(`   ${minQuality} quality: ${qualifiedEmails.length} (${((qualifiedEmails.length/emails.length)*100).toFixed(1)}%)`);
      console.log(`   Providers found: ${Object.keys(summary).length}`);
      console.log(`   Files created: ${savedFiles.length + 1} (including summary.txt)`);
      console.log(`\n📁 Results available at: ${output}/`);
      console.log(`💡 You could access verified emails immediately as they were processed!`);
      
      // Show provider breakdown
      console.log(`\n🏆 Top Providers:`);
      Object.entries(summary)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 5)
        .forEach(([provider, count]) => {
          console.log(`   ${provider}: ${count} emails`);
        });
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Process CSV file
   */
  async processCSV(input, output, options) {
    try {
      this.pipeline.concurrency = parseInt(options.concurrency);
      this.pipeline.includeStats = options.stats;
      
      const result = await this.pipeline.processCSVFile(input, output, {
        emailColumn: options.emailColumn,
        providerColumn: options.providerColumn,
        includeDetails: options.includeDetails,
        separateByProvider: !options.singleFile  // Default to true, false only if --single-file is specified
      });
      
      this.displayProcessingResult(result);
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Process JSON file
   */
  async processJSON(input, output, options) {
    try {
      this.pipeline.concurrency = parseInt(options.concurrency);
      this.pipeline.includeStats = options.stats;
      
      const result = await this.pipeline.processJSONFile(input, output, {
        emailField: options.emailField,
        providerField: options.providerField,
        includeDetails: options.includeDetails
      });
      
      this.displayProcessingResult(result);
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Process plain text list
   */
  async processList(input, output, options) {
    try {
      console.log(`📖 Reading email list: ${input}`);
      const content = await fs.readFile(input, 'utf-8');
      const emails = content
        .split('\n')
        .map(line => line.trim())
        .filter(line => line && line.includes('@'));
      
      if (emails.length === 0) {
        throw new Error('No valid emails found in file');
      }
      
      // Set default concurrency to 15 (good balance of speed and reliability)
      this.pipeline.concurrency = 15;
      
      // Auto-generate output filename if not provided
      if (!output) {
        // Extract filename without extension from input path
        const path = await import('path');
        const inputFilename = path.basename(input, path.extname(input));
        const outputExtension = options.format === 'json' ? 'json' : 'csv';
        output = `output/${inputFilename}_results.${outputExtension}`;
        
        // Ensure output directory exists
        await fs.mkdir('output', { recursive: true });
      }
      
      console.log(`🔧 Processing ${emails.length} emails with concurrency: ${this.pipeline.concurrency}`);
      console.log(`💾 Output will be saved to: ${output}`);
      
      const result = await this.pipeline.processEmailArray(emails, {
        outputFile: output,
        separateByProvider: !options.singleFile  // Default to true, false only if --single-file is specified
      });
      
      console.log(`\n✅ Processing complete! Results saved to: ${output}`);
      this.displayStats(result.stats);
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Process batch of emails from command line
   */
  async processBatch(emails, options) {
    try {
      this.pipeline.concurrency = 15;
      
      const result = await this.pipeline.processEmailArray(emails, {
        outputFile: options.output,
        separateByProvider: !options.singleFile  // Default to true, false only if --single-file is specified
      });
      
      // Display results
      console.log('\n📧 Results:');
      result.results.forEach((res, index) => {
        console.log(`${index + 1}. ${res.email} → ${res.provider}`);
        if (!res.success) {
          console.log(`   ❌ ${res.error}`);
        }
      });
      
      this.displayStats(result.stats);
      
      if (options.output) {
        console.log(`\n✅ Results saved to: ${options.output}`);
      }
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Interactive mode
   */
  async interactiveMode() {
    console.log('🔄 Interactive Email Provider Detection Mode');
    console.log('Enter email addresses one by one, or "quit" to exit\n');
    
    const readline = await import('readline');
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
    
    const askQuestion = (question) => {
      return new Promise((resolve) => {
        rl.question(question, resolve);
      });
    };
    
    try {
      while (true) {
        const email = await askQuestion('Email: ');
        
        if (email.toLowerCase() === 'quit' || email.toLowerCase() === 'exit') {
          break;
        }
        
        if (!email.trim()) {
          continue;
        }
        
        if (!email.includes('@')) {
          console.log('❌ Invalid email format\n');
          continue;
        }
        
        try {
          const result = await detectEmailProvider(email.trim());
          console.log(`   → ${result.provider} ${result.success ? '✅' : '❌'}`);
          if (!result.success) {
            console.log(`   Error: ${result.error}`);
          }
        } catch (error) {
          console.log(`   ❌ Error: ${error.message}`);
        }
        
        console.log('');
      }
    } finally {
      rl.close();
    }
    
    console.log('👋 Goodbye!');
  }

  /**
   * Generate report from results file
   */
  async generateReport(resultsFile, options) {
    try {
      console.log(`📊 Generating report from: ${resultsFile}`);
      
      const content = await fs.readFile(resultsFile, 'utf-8');
      let results;
      
      if (resultsFile.endsWith('.json')) {
        results = JSON.parse(content);
      } else {
        // Parse CSV
        const pipeline = new EmailProviderPipeline();
        const data = pipeline.parseCSV(content);
        results = data.map(row => ({
          email: row.email,
          provider: row.email_provider || row.provider,
          success: row.email_provider_success !== 'false'
        }));
      }
      
      const report = this.pipeline.generateReport(results);
      
      if (options.output) {
        await fs.writeFile(options.output, JSON.stringify(report, null, 2));
        console.log(`✅ Report saved to: ${options.output}`);
      } else {
        console.log('\n📊 Email Provider Report');
        console.log('═'.repeat(50));
        console.log(`Total emails: ${report.summary.total}`);
        console.log(`Successful: ${report.summary.successful}`);
        console.log(`Failed: ${report.summary.failed}`);
        console.log(`Success rate: ${((report.summary.successful / report.summary.total) * 100).toFixed(1)}%`);
        
        console.log('\n🏆 Top Providers:');
        report.topProviders.forEach((provider, index) => {
          console.log(`${index + 1}. ${provider.provider}: ${provider.count} (${provider.percentage}%)`);
        });
        
        if (report.failures.length > 0) {
          console.log(`\n❌ Failed emails: ${report.failures.length}`);
          report.failures.slice(0, 5).forEach(failure => {
            console.log(`   ${failure.email}: ${failure.error}`);
          });
          if (report.failures.length > 5) {
            console.log(`   ... and ${report.failures.length - 5} more`);
          }
        }
      }
      
    } catch (error) {
      console.error('❌ Error:', error.message);
      process.exit(1);
    }
  }

  /**
   * Display processing results
   */
  displayProcessingResult(result) {
    console.log('\n✅ Processing Complete!');
    console.log(`📁 Input: ${result.inputFile}`);
    console.log(`📁 Output: ${result.outputFile}`);
    console.log(`📊 Total rows/records: ${result.totalRows || result.totalRecords}`);
    console.log(`📧 Emails processed: ${result.emailsProcessed}`);
    
    this.displayStats(result.stats);
  }

  /**
   * Activate license key
   */
  async activateLicense(licenseKey) {
    try {
      console.log('🔄 Activating license...');
      console.log('   Gathering machine information...');
      
      const result = await activateLicense(licenseKey);
      
      console.log('✅ License activated successfully!');
      console.log('\n🔒 License Details:');
      console.log(`   License Key: ${licenseKey}`);
      console.log(`   Machine: ${result.machineInfo.hostname} (${result.machineInfo.platform})`);
      console.log(`   Fingerprint: ${result.machineInfo.fingerprint}`);
      console.log(`   Activated: ${result.binding.activatedAt}`);
      console.log(`   IP Address: ${result.binding.ip}`);
      console.log('\n🚀 You can now use all premium features.');
      console.log('\n⚠️  This license is now bound to this specific machine.');
    } catch (error) {
      console.error('❌ License activation failed:', error.message);
      if (error.message.includes('already activated on another machine')) {
        console.log('\n💡 Note: Each license can only be used on one machine for security.');
        console.log('   Contact administrator if you need to transfer your license.');
      }
      process.exit(1);
    }
  }

  /**
   * Show license status
   */
  async showLicenseStatus() {
    try {
      const status = await getLicenseStatus();
      
      console.log('🔑 License Status:');
      
      if (status.status === 'active') {
        console.log('✅ Status: Active');
        console.log(`📄 License: ${status.license}`);
        console.log(`📍 Source: ${status.source}`);
        
        console.log('\n🖥️  Machine Information:');
        console.log(`   Current Machine: ${status.machineInfo.current.hostname} (${status.machineInfo.current.platform})`);
        console.log(`   Current Fingerprint: ${status.machineInfo.current.fingerprint}`);
        console.log(`   Current IP: ${status.currentIP}`);
        
        if (status.binding) {
          console.log('\n🔒 License Binding:');
          console.log(`   Bound to Machine: ${status.binding.hostname} (${status.binding.platform})`);
          console.log(`   Bound Fingerprint: ${status.binding.fingerprint}`);
          console.log(`   Activation Date: ${status.binding.activatedAt}`);
          console.log(`   Last Used: ${status.binding.lastUsed}`);
          console.log(`   Registered IP: ${status.binding.ip}`);
          
          // Check if machine matches
          const isCorrectMachine = status.machineInfo.current.fingerprint === status.binding.fingerprint;
          console.log(`   Machine Match: ${isCorrectMachine ? '✅ Yes' : '❌ No'}`);
        }
      } else if (status.status === 'error') {
        console.log('❌ Status: Error');
        console.log(`   ${status.error}`);
        console.log('\n🖥️  Current Machine:');
        console.log(`   Hostname: ${status.machineInfo?.current?.hostname || 'Unknown'}`);
        console.log(`   Fingerprint: ${status.machineInfo?.current?.fingerprint || 'Unknown'}`);
      } else {
        console.log('❌ Status: Inactive');
        console.log('📋 Use "activate <license-key>" to activate your license');
        
        console.log('\n🖥️  Current Machine:');
        console.log(`   Hostname: ${status.machineInfo.current.hostname}`);
        console.log(`   Fingerprint: ${status.machineInfo.current.fingerprint}`);
        console.log(`   IP Address: ${status.currentIP}`);
      }
    } catch (error) {
      console.error('❌ Error checking license:', error.message);
    }
  }

  /**
   * Generate new license key (admin function)
   */
  async generateKey() {
    try {
      const newKey = generateLicenseKey();
      console.log('🔑 Generated License Key:');
      console.log(newKey);
      console.log('\n⚠️  Save this key securely and provide to authorized users.');
      console.log('\n📝 Note: Generated keys must be manually added to VALID_LICENSES in src/auth.js to become active.');
    } catch (error) {
      console.error('❌ Error generating key:', error.message);
    }
  }

  /**
   * List all license bindings (admin function)
   */
  async listBindings() {
    try {
      const bindings = await listAllBindings();
      
      console.log('🔒 All License Bindings:');
      console.log('═'.repeat(80));
      
      if (Object.keys(bindings).length === 0) {
        console.log('No license bindings found.');
        return;
      }
      
      Object.entries(bindings).forEach(([license, binding], index) => {
        console.log(`\n${index + 1}. License: ${license}`);
        console.log(`   Machine: ${binding.hostname} (${binding.platform})`);
        console.log(`   Fingerprint: ${binding.fingerprint}`);
        console.log(`   MAC Address: ${binding.macAddress}`);
        console.log(`   IP Address: ${binding.ip}`);
        console.log(`   Activated: ${binding.activatedAt}`);
        console.log(`   Last Used: ${binding.lastUsed}`);
      });
      
      console.log(`\n📊 Total licenses bound: ${Object.keys(bindings).length}`);
      
    } catch (error) {
      console.error('❌ Error listing bindings:', error.message);
    }
  }

  /**
   * Display statistics
   */
  displayStats(stats) {
    console.log('\n📊 Statistics:');
    console.log(`   Total emails: ${stats.total}`);
    console.log(`   Success rate: ${((stats.successful / stats.total) * 100).toFixed(1)}%`);
    
    // Show category breakdown if available
    if (stats.categories && Object.keys(stats.categories).length > 0) {
      console.log(`\n📁 Categories:`);
      Object.entries(stats.categories)
        .sort(([,a], [,b]) => b - a)
        .forEach(([category, count]) => {
          const percentage = ((count / stats.successful) * 100).toFixed(1);
          console.log(`     ${category}: ${count} (${percentage}%)`);
        });
    }
    
    // Show security services vs regular providers
    if (stats.securityServices || stats.emailProviders) {
      console.log(`\n🛡️  Protection Types:`);
      if (stats.emailProviders > 0) {
        console.log(`     Email Providers: ${stats.emailProviders}`);
      }
      if (stats.securityServices > 0) {
        console.log(`     🛡️  Security Services: ${stats.securityServices}`);
      }
    }
    
    console.log(`\n🏆 Top Providers:`);
    Object.entries(stats.providers)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 8)
      .forEach(([provider, count]) => {
        const percentage = ((count / stats.successful) * 100).toFixed(1);
        const icon = provider.includes('Security') ? '🛡️ ' : '📧 ';
        console.log(`     ${icon}${provider}: ${count} (${percentage}%)`);
      });
    
    if (Object.keys(stats.providers).length > 8) {
      console.log(`     ... and ${Object.keys(stats.providers).length - 8} more`);
    }
  }

  /**
   * Run CLI
   */
  run() {
    this.setupCommands();
    program.parse();
  }
}

// Create and run CLI
const cli = new EmailProviderCLI();
cli.run(); 