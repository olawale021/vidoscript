import { resolveMx } from 'dns/promises';
import { setTimeout } from 'node:timers/promises';

/**
 * Provider mapping based on MX record hostnames
 */
const PROVIDER_MAPPING = {
  // Google/Gmail
  'gmail': 'Gmail',
  'google': 'Google Workspace',
  'googlemail': 'Gmail',
  'aspmx.l.google.com': 'Google Workspace',
  
  // Microsoft/Office 365
  'outlook': 'Microsoft 365',
  'office365': 'Microsoft 365',
  'hotmail': 'Outlook.com',
  'live': 'Outlook.com',
  '.mail.protection.outlook.com': 'Microsoft 365',
  'onmicrosoft.com': 'Microsoft 365',
  'owa': 'OWA (Outlook Web Access)',
  
  // GoDaddy
  'secureserver': 'GoDaddy',
  'mailstore1.secureserver.net': 'GoDaddy',
  
  // Zoho
  'zoho': 'Zoho Mail',
  'zohomail': 'Zoho Mail',
  
  // Barracuda Email Security
  'barracuda': 'Barracuda Email Security',
  'barracudacentral': 'Barracuda Email Security',
  'barracudanetworks': 'Barracuda Email Security',
  'spam.barracuda': 'Barracuda Email Security',
  'mail.protection.barracuda': 'Barracuda Email Security',
  'ess.barracuda': 'Barracuda Email Security',
  'bsn.barracuda': 'Barracuda Email Security',
  'asp.barracuda': 'Barracuda Email Security',
  'mx.barracuda': 'Barracuda Email Security',
  'filter.barracuda': 'Barracuda Email Security',
  'gateway.barracuda': 'Barracuda Email Security',
  
  // Other email security providers (enterprise)
  'mimecast': 'Mimecast Email Security',
  'proofpoint': 'Proofpoint Email Security',
  'sophos': 'Sophos Email Security',
  'forcepoint': 'Forcepoint Email Security',
  'cisco.email': 'Cisco Email Security',
  'symantec.cloud': 'Symantec Email Security',
  'messagelabs': 'Symantec Email Security',
  'appriver': 'AppRiver Email Security',
  'ironport': 'Cisco IronPort',
  'trend.micro': 'Trend Micro Email Security',
  
  // Other popular providers
  'yandex': 'Yandex Mail',
  'mailgun': 'Mailgun',
  'sendgrid': 'SendGrid',
  'amazonses': 'Amazon SES',
  'sparkpostmail': 'SparkPost',
  'mailchimp': 'Mailchimp',
  'constantcontact': 'Constant Contact',
  'icloud': 'iCloud Mail',
  'yahoo': 'Yahoo Mail',
  'aol': 'AOL Mail',
  'protonmail': 'ProtonMail',
  'fastmail': 'FastMail',
  'rackspace': 'Rackspace Email',
  'hover': 'Hover Email',
  'serverdata': 'ServerData Email',
  'serverdatanet': 'ServerData Email',
  'server-data': 'ServerData Email',
  'netsol': 'NetSol Email',
  'netsol.com': 'NetSol Email',
  'networksolutions': 'NetSol Email'
};

/**
 * DNS timeout configuration
 */
const DNS_SERVERS = ['8.8.8.8', '1.1.1.1', '8.8.4.4', '1.0.0.1'];
const DNS_TIMEOUT = 5000; // 5 seconds

/**
 * Extract domain from email address
 * @param {string} email - Email address
 * @returns {string} Domain part of the email
 */
export function extractDomain(email) {
  if (!email || typeof email !== 'string') {
    throw new Error('Invalid email address');
  }
  
  const emailRegex = /^[^\s@]+@([^\s@]+\.[^\s@]+)$/;
  const match = email.match(emailRegex);
  
  if (!match) {
    throw new Error('Invalid email format');
  }
  
  return match[1].toLowerCase();
}

/**
 * Get MX records for a domain with timeout and error handling
 * @param {string} domain - Domain to lookup
 * @param {number} retries - Number of retry attempts (default: 2)
 * @returns {Promise<Array>} Array of MX records sorted by priority
 */
export async function getMxRecords(domain, retries = 2) {
  let lastError;
  
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      // Add delay between retries (except first attempt)
      if (attempt > 0) {
        await setTimeout(1000 * attempt); // Progressive delay: 1s, 2s
      }
      
      // Race between DNS lookup and timeout
      const mxRecords = await Promise.race([
        resolveMx(domain),
        setTimeout(DNS_TIMEOUT).then(() => {
          throw new Error('DNS lookup timeout');
        })
      ]);
      
      // Sort by priority (lower priority = higher precedence)
      return mxRecords
        .sort((a, b) => a.priority - b.priority)
        .map(record => record.exchange.toLowerCase());
        
    } catch (error) {
      lastError = error;
      
      // Don't retry for certain permanent errors
      if (error.code === 'ENOTFOUND' || error.code === 'ENODATA') {
        break;
      }
      
      // Continue retrying for timeout and other network errors
      if (attempt < retries && (error.message === 'DNS lookup timeout' || error.code === 'ECONNRESET' || error.code === 'ETIMEDOUT')) {
        continue;
      }
    }
  }
  
  // Handle final error after all retries
  if (lastError.code === 'ENOTFOUND') {
    throw new Error(`Domain not found: ${domain}`);
  } else if (lastError.code === 'ENODATA') {
    throw new Error(`No MX records found for domain: ${domain}`);
  } else if (lastError.message === 'DNS lookup timeout') {
    throw new Error(`DNS lookup timeout for domain: ${domain} (after ${retries + 1} attempts)`);
  } else {
    throw new Error(`DNS lookup failed for ${domain}: ${lastError.message}`);
  }
}

/**
 * Provider categories for better classification
 */
const PROVIDER_CATEGORIES = {
  'Gmail': { type: 'consumer', category: 'Email Provider' },
  'Google Workspace': { type: 'business', category: 'Email Provider' },
  'Microsoft 365': { type: 'business', category: 'Email Provider' },
  'Outlook.com': { type: 'consumer', category: 'Email Provider' },
  'Yahoo Mail': { type: 'consumer', category: 'Email Provider' },
  'Zoho Mail': { type: 'business', category: 'Email Provider' },
  'ServerData Email': { type: 'business', category: 'Email Provider' },
  'OWA (Outlook Web Access)': { type: 'business', category: 'Email Provider' },
  'NetSol Email': { type: 'business', category: 'Email Provider' },
  'Barracuda Email Security': { type: 'enterprise', category: 'Email Security Service' },
  'Mimecast Email Security': { type: 'enterprise', category: 'Email Security Service' },
  'Proofpoint Email Security': { type: 'enterprise', category: 'Email Security Service' },
  'Sophos Email Security': { type: 'enterprise', category: 'Email Security Service' },
  'Cisco Email Security': { type: 'enterprise', category: 'Email Security Service' },
  'Cisco IronPort': { type: 'enterprise', category: 'Email Security Service' },
  'Symantec Email Security': { type: 'enterprise', category: 'Email Security Service' },
  'AppRiver Email Security': { type: 'enterprise', category: 'Email Security Service' },
  'Forcepoint Email Security': { type: 'enterprise', category: 'Email Security Service' },
  'Trend Micro Email Security': { type: 'enterprise', category: 'Email Security Service' }
};

/**
 * Detect email provider based on MX records
 * @param {Array<string>} mxHosts - Array of MX hostnames
 * @returns {Object} Object containing provider info or "Unknown"
 */
export function detectProvider(mxHosts) {
  if (!Array.isArray(mxHosts) || mxHosts.length === 0) {
    return {
      name: 'Unknown',
      type: 'unknown',
      category: 'Unknown',
      isSecurityService: false
    };
  }
  
  // Check each MX host against our provider mapping
  for (const hostname of mxHosts) {
    const hostnameLower = hostname.toLowerCase();
    
    // Check for exact matches or substring matches
    for (const [key, provider] of Object.entries(PROVIDER_MAPPING)) {
      if (hostnameLower.includes(key.toLowerCase())) {
        const providerInfo = PROVIDER_CATEGORIES[provider] || { 
          type: 'unknown', 
          category: 'Email Provider',
          isSecurityService: false
        };
        
        return {
          name: provider,
          type: providerInfo.type,
          category: providerInfo.category,
          isSecurityService: providerInfo.category === 'Email Security Service',
          mxHostname: hostname
        };
      }
    }
  }
  
  return {
    name: 'Unknown',
    type: 'unknown', 
    category: 'Unknown',
    isSecurityService: false,
    mxHostname: mxHosts[0]
  };
}

/**
 * Main function to detect email provider
 * @param {string} email - Email address to analyze
 * @returns {Promise<Object>} Object containing email, domain, mxRecords, and provider
 */
export async function detectEmailProvider(email) {
  try {
    // Extract domain from email
    const domain = extractDomain(email);
    
    // Get MX records for the domain
    const mxRecords = await getMxRecords(domain);
    
    // Detect provider based on MX records
    const providerInfo = detectProvider(mxRecords);
    
    return {
      email: email,
      domain: domain,
      mxRecords: mxRecords,
      provider: providerInfo.name,
      providerType: providerInfo.type,
      providerCategory: providerInfo.category,
      isSecurityService: providerInfo.isSecurityService,
      mxHostname: providerInfo.mxHostname,
      success: true
    };
    
  } catch (error) {
    return {
      email: email,
      domain: null,
      mxRecords: [],
      provider: 'Unknown',
      providerType: 'unknown',
      providerCategory: 'Unknown',
      isSecurityService: false,
      mxHostname: null,
      success: false,
      error: error.message
    };
  }
}

/**
 * Batch process multiple email addresses
 * @param {Array<string>} emails - Array of email addresses
 * @param {number} concurrency - Number of concurrent lookups (default: 5)
 * @param {Object} options - Processing options
 * @returns {Promise<Array>} Array of detection results
 */
export async function detectEmailProviders(emails, concurrency = 15, options = {}) {
  if (!Array.isArray(emails)) {
    throw new Error('Emails must be an array');
  }
  
  const showProgress = options.showProgress !== false;
  const results = [];
  let processedCount = 0;
  
  // Process emails in batches to avoid overwhelming DNS servers
  for (let i = 0; i < emails.length; i += concurrency) {
    const batch = emails.slice(i, i + concurrency);
    
    const batchPromises = batch.map(async (email, batchIndex) => {
      const globalIndex = i + batchIndex;
      
      try {
        const result = await detectEmailProvider(email);
        
        if (showProgress) {
          const status = result.success ? '✅' : '❌';
          const provider = result.success ? result.provider : 'Failed';
          const countDisplay = `[${globalIndex + 1}/${emails.length}]`;
          const paddedEmail = email.padEnd(50, ' ');
          console.log(`${countDisplay} ${paddedEmail} ${status} ${provider}`);
        }
        
        return result;
      } catch (error) {
        const failedResult = {
          email: email,
          domain: null,
          mxRecords: [],
          provider: 'Unknown',
          success: false,
          error: error.message
        };
        
        if (showProgress) {
          const countDisplay = `[${globalIndex + 1}/${emails.length}]`;
          const paddedEmail = email.padEnd(50, ' ');
          console.log(`${countDisplay} ${paddedEmail} ❌ ${error.message}`);
        }
        
        return failedResult;
      }
    });
    
    const batchResults = await Promise.allSettled(batchPromises);
    
    // Extract results and handle any rejections
    const processedResults = batchResults.map((result, index) => {
      if (result.status === 'fulfilled') {
        return result.value;
      } else {
        return {
          email: batch[index],
          domain: null,
          mxRecords: [],
          provider: 'Unknown',
          success: false,
          error: result.reason?.message || 'Unknown error'
        };
      }
    });
    
    results.push(...processedResults);
    processedCount += batch.length;
    
    // Longer delay between batches to be respectful to DNS servers
    if (i + concurrency < emails.length) {
      await setTimeout(500); // Increased from 100ms to 500ms
    }
  }
  
  if (showProgress) {
    const successful = results.filter(r => r.success).length;
    const failed = results.length - successful;
    console.log(`\n✅ Completed: ${successful} successful, ${failed} failed (${emails.length} total)`);
  }
  
  return results;
}

/**
 * Get statistics about detected providers
 * @param {Array} results - Array of detection results
 * @returns {Object} Statistics object
 */
export function getProviderStats(results) {
  const stats = {
    total: results.length,
    successful: 0,
    failed: 0,
    providers: {},
    categories: {},
    securityServices: 0,
    emailProviders: 0
  };
  
  results.forEach(result => {
    if (result.success) {
      stats.successful++;
      stats.providers[result.provider] = (stats.providers[result.provider] || 0) + 1;
      
      // Track categories
      const category = result.providerCategory || 'Unknown';
      stats.categories[category] = (stats.categories[category] || 0) + 1;
      
      // Count security services vs email providers
      if (result.isSecurityService) {
        stats.securityServices++;
      } else if (category === 'Email Provider') {
        stats.emailProviders++;
      }
    } else {
      stats.failed++;
    }
  });
  
  return stats;
} 