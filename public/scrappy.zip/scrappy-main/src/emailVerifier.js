import { createConnection } from 'net';
import { setTimeout as delay } from 'node:timers/promises';

/**
 * Known disposable email providers
 */
const DISPOSABLE_DOMAINS = new Set([
  '10minutemail.com', 'guerrillamail.com', 'mailinator.com', 'temp-mail.org',
  'throwaway.email', 'getnada.com', 'maildrop.cc', 'mohmal.com',
  'yopmail.com', 'tempmail.plus', 'mail.tm', 'emailondeck.com',
  'sharklasers.com', 'grr.la', 'guerrillamailblock.com', 'spamgourmet.com',
  'dispostable.com', 'mailtemp.info', 'mytrashmail.com', 'tmpemail.com'
]);

/**
 * Common role-based email prefixes
 */
const ROLE_PREFIXES = new Set([
  'admin', 'administrator', 'support', 'help', 'info', 'contact', 'sales',
  'marketing', 'webmaster', 'postmaster', 'abuse', 'noreply', 'no-reply',
  'billing', 'accounts', 'security', 'team', 'office', 'general', 'mail',
  'service', 'services', 'customerservice', 'hr', 'legal', 'finance'
]);

/**
 * Universal timeout wrapper for any promise
 * @param {Promise} promise - Promise to wrap with timeout
 * @param {number} timeoutMs - Timeout in milliseconds
 * @param {string} operation - Name of operation for error message
 * @returns {Promise} Promise that resolves/rejects within timeout
 */
export function withTimeout(promise, timeoutMs = 5000, operation = 'operation') {
  return Promise.race([
    promise,
    delay(timeoutMs).then(() => {
      throw new Error(`${operation} timeout after ${timeoutMs}ms`);
    })
  ]);
}

/**
 * Enhanced email syntax validation
 * @param {string} email - Email address to validate
 * @returns {Object} Validation result
 */
export function validateEmailSyntax(email) {
  const result = {
    valid: false,
    issues: []
  };

  if (!email || typeof email !== 'string') {
    result.issues.push('Email is required');
    return result;
  }

  // Basic format check
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    result.issues.push('Invalid email format');
    return result;
  }

  // More detailed validation
  const [localPart, domain] = email.split('@');

  // Local part validation
  if (localPart.length === 0) {
    result.issues.push('Missing local part');
  } else if (localPart.length > 64) {
    result.issues.push('Local part too long (max 64 characters)');
  } else if (localPart.startsWith('.') || localPart.endsWith('.')) {
    result.issues.push('Local part cannot start or end with a dot');
  } else if (localPart.includes('..')) {
    result.issues.push('Local part cannot contain consecutive dots');
  }

  // Domain validation
  if (domain.length === 0) {
    result.issues.push('Missing domain');
  } else if (domain.length > 253) {
    result.issues.push('Domain too long (max 253 characters)');
  } else if (!domain.includes('.')) {
    result.issues.push('Domain must contain at least one dot');
  } else if (domain.startsWith('-') || domain.endsWith('-')) {
    result.issues.push('Domain cannot start or end with a hyphen');
  }

  // TLD validation
  const tld = domain.split('.').pop();
  if (tld.length < 2) {
    result.issues.push('TLD too short (minimum 2 characters)');
  }

  result.valid = result.issues.length === 0;
  return result;
}

/**
 * Check if email is from a disposable email provider
 * @param {string} email - Email address to check
 * @returns {Object} Disposable check result
 */
export function checkDisposable(email) {
  try {
    const domain = email.split('@')[1]?.toLowerCase();
    const isDisposable = DISPOSABLE_DOMAINS.has(domain);
    
    return {
      isDisposable,
      domain,
      confidence: isDisposable ? 'high' : 'low'
    };
  } catch (error) {
    return {
      isDisposable: false,
      domain: null,
      confidence: 'unknown',
      error: error.message
    };
  }
}

/**
 * Check if email is a role-based account
 * @param {string} email - Email address to check
 * @returns {Object} Role account check result
 */
export function checkRoleAccount(email) {
  try {
    const localPart = email.split('@')[0]?.toLowerCase();
    const isRole = ROLE_PREFIXES.has(localPart);
    
    return {
      isRole,
      localPart,
      confidence: isRole ? 'high' : 'low'
    };
  } catch (error) {
    return {
      isRole: false,
      localPart: null,
      confidence: 'unknown',
      error: error.message
    };
  }
}

/**
 * SMTP verification - Connect to mail server and verify email existence
 * @param {string} email - Email address to verify
 * @param {string} mxHost - MX host to connect to
 * @param {number} timeout - Connection timeout in ms
 * @returns {Promise<Object>} SMTP verification result
 */
export async function smtpVerify(email, mxHost, timeout = 5000) {
  // Use withTimeout wrapper to ensure absolute timeout
  return withTimeout(
    new Promise((resolve) => {
      const socket = createConnection(25, mxHost);
      let step = 0;
      let response = '';
      let isValid = false;
      let error = null;

      const commands = [
        `HELO verification.tool\r\n`,
        `MAIL FROM:<verify@verification.tool>\r\n`,
        `RCPT TO:<${email}>\r\n`,
        `QUIT\r\n`
      ];

      const cleanup = () => {
        socket.removeAllListeners();
        if (!socket.destroyed) {
          socket.destroy();
        }
      };

      // Use globalThis.setTimeout to avoid conflict with imported setTimeout
      const timeoutId = globalThis.setTimeout(() => {
        error = 'SMTP connection timeout';
        cleanup();
        resolve({ valid: false, error, response: response.trim() });
      }, timeout);

      socket.on('connect', () => {
        // Wait for server greeting
      });

      socket.on('data', (data) => {
        response += data.toString();
        const lines = response.split('\r\n');
        const lastLine = lines[lines.length - 2] || lines[lines.length - 1];

        if (step === 0 && lastLine.startsWith('220')) {
          // Server greeting received
          socket.write(commands[step]);
          step++;
        } else if (step === 1 && lastLine.startsWith('250')) {
          // HELO accepted
          socket.write(commands[step]);
          step++;
        } else if (step === 2 && lastLine.startsWith('250')) {
          // MAIL FROM accepted
          socket.write(commands[step]);
          step++;
        } else if (step === 3) {
          // RCPT TO response
          if (lastLine.startsWith('250')) {
            isValid = true;
          } else if (lastLine.startsWith('550') || lastLine.startsWith('551') || lastLine.startsWith('553')) {
            isValid = false;
          } else {
            // Uncertain response
            isValid = null;
          }
          socket.write(commands[step]); // QUIT
          step++;
        } else if (lastLine.startsWith('4') || lastLine.startsWith('5')) {
          // Error response
          error = `SMTP error: ${lastLine}`;
          cleanup();
          globalThis.clearTimeout(timeoutId);
          resolve({ valid: false, error, response: response.trim() });
          return;
        }
      });

      socket.on('close', () => {
        globalThis.clearTimeout(timeoutId);
        resolve({
          valid: isValid,
          error,
          response: response.trim(),
          confidence: isValid === null ? 'uncertain' : 'high'
        });
      });

      socket.on('error', (err) => {
        error = `Connection error: ${err.message}`;
        cleanup();
        globalThis.clearTimeout(timeoutId);
        resolve({ valid: false, error, response: response.trim() });
      });
    }),
    timeout,
    'SMTP verification'
  );
}

/**
 * Comprehensive email verification with timeout
 * @param {string} email - Email address to verify
 * @param {Array<string>} mxRecords - MX records for the domain
 * @param {Object} options - Verification options
 * @returns {Promise<Object>} Complete verification result
 */
export async function verifyEmail(email, mxRecords = [], options = {}) {
  const timeout = options.smtpTimeout || options.timeout || 5000;
  
  // Wrap entire verification in timeout to ensure it never hangs
  return withTimeout(
    (async () => {
      const result = {
        email,
        valid: false,
        score: 0,
        checks: {},
        recommendations: [],
        timestamp: new Date().toISOString()
      };

      try {
        // 1. Syntax validation (fast, no timeout needed)
        result.checks.syntax = validateEmailSyntax(email);
        if (!result.checks.syntax.valid) {
          result.recommendations.push('Fix email syntax issues');
          return result;
        }
        result.score += 20;

        // 2. Disposable email check (fast, no timeout needed)
        result.checks.disposable = checkDisposable(email);
        if (result.checks.disposable.isDisposable) {
          result.recommendations.push('Consider avoiding disposable email addresses');
          result.score -= 30;
        } else {
          result.score += 15;
        }

        // 3. Role account check (fast, no timeout needed)
        result.checks.roleAccount = checkRoleAccount(email);
        if (result.checks.roleAccount.isRole) {
          result.recommendations.push('Role-based email detected - may not be personal');
          result.score -= 10;
        } else {
          result.score += 10;
        }

        // 4. MX record check
        result.checks.mxRecords = {
          available: mxRecords.length > 0,
          count: mxRecords.length,
          records: mxRecords.slice(0, 3) // Store first 3 for reference
        };
        
        if (mxRecords.length > 0) {
          result.score += 25;
        } else {
          result.recommendations.push('Domain has no MX records - cannot receive emails');
          return result;
        }

        // 5. SMTP verification (optional and careful) with timeout
        if (options.smtpVerify && mxRecords.length > 0) {
          try {
            const primaryMx = mxRecords[0];
            // Use shorter timeout for SMTP to leave buffer for other operations
            const smtpTimeout = Math.min(timeout - 1000, 4000); // Reserve 1s for other operations, max 4s for SMTP
            result.checks.smtp = await smtpVerify(email, primaryMx, smtpTimeout);
            
            if (result.checks.smtp.valid === true) {
              result.score += 30;
            } else if (result.checks.smtp.valid === false) {
              result.recommendations.push('SMTP verification failed - email may not exist');
              result.score -= 20;
            } else {
              result.recommendations.push('SMTP verification uncertain - server did not provide clear response');
            }
          } catch (error) {
            result.checks.smtp = {
              valid: null,
              error: error.message,
              confidence: 'failed'
            };
            result.recommendations.push('SMTP verification failed due to technical issues');
          }
        }

        // Calculate final validity
        result.score = Math.max(0, Math.min(100, result.score));
        result.valid = result.score >= 70;

        // Add quality assessment
        if (result.score >= 90) {
          result.quality = 'excellent';
        } else if (result.score >= 80) {
          result.quality = 'good';
        } else if (result.score >= 70) {
          result.quality = 'acceptable';
        } else if (result.score >= 50) {
          result.quality = 'not sure';
        } else {
          result.quality = 'poor';
        }

        return result;

      } catch (error) {
        result.error = error.message;
        result.recommendations.push('Verification failed due to technical error');
        return result;
      }
    })(),
    timeout,
    `Email verification for ${email}`
  );
}

/**
 * Batch email verification with robust timeout handling
 * @param {Array<string>} emails - Array of email addresses
 * @param {Function} getMxRecordsFunc - Function to get MX records
 * @param {Object} options - Verification options
 * @returns {Promise<Array>} Array of verification results
 */
export async function verifyEmails(emails, getMxRecordsFunc, options = {}) {
  const results = [];
  const concurrency = options.concurrency || 15;
  const timeout = options.smtpTimeout || options.timeout || 5000;
  
  console.log(`\n🔍 Verifying ${emails.length} email addresses with ${timeout}ms timeout...`);
  
  for (let i = 0; i < emails.length; i += concurrency) {
    const batch = emails.slice(i, i + concurrency);
    
    const batchPromises = batch.map(async (email, batchIndex) => {
      const globalIndex = i + batchIndex;
      
      return withTimeout(
        (async () => {
          try {
            // Get MX records first with timeout
            let mxRecords = [];
            try {
              const domain = email.split('@')[1];
              mxRecords = await withTimeout(
                getMxRecordsFunc(domain),
                Math.min(timeout - 1000, 3000), // Reserve time for verification, max 3s for DNS
                `MX lookup for ${domain}`
              );
            } catch (error) {
              // MX lookup failed, but continue with other checks
              // console.log(`   DNS lookup failed for ${domain}: ${error.message}`);
            }
            
            // Verify email with remaining timeout
            const result = await verifyEmail(email, mxRecords, { ...options, timeout });
            
            // Display progress
            const paddedEmail = email.padEnd(50, ' ');
            const status = result.valid ? '✅' : '❌';
            const quality = result.quality || 'unknown';
            const scoreDisplay = `${result.score}/100`;
            
            console.log(`[${globalIndex + 1}/${emails.length}] ${paddedEmail} ${status} ${quality} (${scoreDisplay})`);
            
            return result;
            
          } catch (error) {
            const failedResult = {
              email,
              valid: false,
              score: 0,
              quality: 'failed',
              error: error.message,
              timestamp: new Date().toISOString()
            };
            
            const paddedEmail = email.padEnd(50, ' ');
            console.log(`[${globalIndex + 1}/${emails.length}] ${paddedEmail} ❌ failed (${error.message})`);
            
            return failedResult;
          }
        })(),
        timeout + 1000, // Add small buffer to overall timeout
        `Email verification for ${email}`
      );
    });
    
    const batchResults = await Promise.allSettled(batchPromises);
    const processedResults = batchResults.map((result, index) => {
      return result.status === 'fulfilled' ? result.value : {
        email: batch[index],
        valid: false,
        score: 0,
        quality: 'timeout',
        error: result.reason?.message || 'Operation timed out',
        timestamp: new Date().toISOString()
      };
    });
    
    results.push(...processedResults);
    
    // Small delay between batches
    if (i + concurrency < emails.length) {
      await delay(100);  // Reduced delay since individual timeouts are now enforced
    }
  }
  
  const validCount = results.filter(r => r.valid).length;
  const totalCount = results.length;
  
  console.log(`\n✅ Verification complete: ${validCount}/${totalCount} emails are valid (${((validCount/totalCount)*100).toFixed(1)}%)`);
  
  return results;
} 