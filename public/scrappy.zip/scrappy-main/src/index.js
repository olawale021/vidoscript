#!/usr/bin/env node

import {
    detectEmailProvider,
    detectEmailProviders,
    getProviderStats
} from './emailProviderDetector.js';

/**
 * Demo email addresses for testing different providers
 */
const DEMO_EMAILS = [
  'user@gmail.com',
  'john@company.onmicrosoft.com',
  'test@outlook.com',
  'support@zoho.com',
  'admin@example.com', // This should show as Unknown
  'info@yahoo.com',
  'contact@protonmail.com'
];

/**
 * Format and display results in a nice table format
 */
function displayResults(results) {
  console.log('\n📧 Email Provider Detection Results');
  console.log('═'.repeat(80));
  
  results.forEach((result, index) => {
    console.log(`\n${index + 1}. ${result.email}`);
    console.log(`   Domain: ${result.domain || 'N/A'}`);
    console.log(`   Provider: ${result.provider}`);
    console.log(`   Status: ${result.success ? '✅ Success' : '❌ Failed'}`);
    
    if (result.success && result.mxRecords?.length > 0) {
      console.log(`   MX Records: ${result.mxRecords.slice(0, 2).join(', ')}${result.mxRecords.length > 2 ? '...' : ''}`);
    }
    
    if (!result.success && result.error) {
      console.log(`   Error: ${result.error}`);
    }
  });
}

/**
 * Display provider statistics
 */
function displayStats(stats) {
  console.log('\n📊 Provider Statistics');
  console.log('═'.repeat(40));
  console.log(`Total emails: ${stats.total}`);
  console.log(`Successful: ${stats.successful}`);
  console.log(`Failed: ${stats.failed}`);
  console.log(`Success rate: ${((stats.successful / stats.total) * 100).toFixed(1)}%`);
  
  if (Object.keys(stats.providers).length > 0) {
    console.log('\nProvider breakdown:');
    Object.entries(stats.providers)
      .sort(([,a], [,b]) => b - a)
      .forEach(([provider, count]) => {
        console.log(`  ${provider}: ${count} (${((count / stats.successful) * 100).toFixed(1)}%)`);
      });
  }
}

/**
 * Main demo function
 */
async function runDemo() {
  console.log('🚀 Starting Email Provider Detection Demo\n');
  
  try {
    // Test single email detection
    console.log('Testing single email detection...');
    const singleResult = await detectEmailProvider('test@gmail.com');
    console.log('Single test result:', singleResult);
    
    // Test batch detection
    console.log('\nTesting batch email detection...');
    const results = await detectEmailProviders(DEMO_EMAILS, 3, { showProgress: true });
    
    // Display results
    displayResults(results);
    
    // Display statistics
    const stats = getProviderStats(results);
    displayStats(stats);
    
    console.log('\n✅ Demo completed successfully!');
    
  } catch (error) {
    console.error('❌ Demo failed:', error.message);
    process.exit(1);
  }
}

/**
 * Handle command line arguments
 */
async function handleCliArgs() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    return runDemo();
  }
  
  // Handle individual email argument
  if (args[0] && args[0].includes('@')) {
    console.log(`🔍 Analyzing email: ${args[0]}\n`);
    
    try {
      const result = await detectEmailProvider(args[0]);
      displayResults([result]);
      
      if (result.success) {
        console.log('\n📋 Additional Details:');
        console.log(`   Domain: ${result.domain}`);
        console.log(`   All MX Records: ${result.mxRecords.join(', ')}`);
      }
      
    } catch (error) {
      console.error('❌ Analysis failed:', error.message);
      process.exit(1);
    }
    
    return;
  }
  
  // Show help
  console.log(`
📧 Email Provider Detector

Usage:
  node src/index.js                    # Run demo with sample emails
  node src/index.js user@example.com   # Analyze specific email
  node src/index.js --help             # Show this help

Examples:
  node src/index.js john@gmail.com
  node src/index.js admin@company.onmicrosoft.com
  `);
}

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Run the CLI handler
if (import.meta.url === `file://${process.argv[1]}`) {
  handleCliArgs();
} 