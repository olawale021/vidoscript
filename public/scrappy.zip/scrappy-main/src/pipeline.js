import fs from 'fs/promises';
import path from 'path';
import { detectEmailProviders, getProviderStats } from './emailProviderDetector.js';

/**
 * CSV utilities for processing email data
 */
export class EmailProviderPipeline {
  constructor(options = {}) {
    this.concurrency = options.concurrency || 15;
    this.outputDir = options.outputDir || './output';
    this.includeStats = options.includeStats !== false;
  }

  /**
   * Parse CSV content into array of objects
   * @param {string} csvContent - CSV file content
   * @returns {Array<Object>} Array of parsed CSV rows
   */
  parseCSV(csvContent) {
    const lines = csvContent.trim().split('\n');
    if (lines.length === 0) {
      return [];
    }

    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const rows = [];

    for (let i = 1; i < lines.length; i++) {
      const values = this.parseCSVLine(lines[i]);
      if (values.length === headers.length) {
        const row = {};
        headers.forEach((header, index) => {
          row[header] = values[index];
        });
        rows.push(row);
      }
    }

    return rows;
  }

  /**
   * Parse a single CSV line handling quotes and commas
   * @param {string} line - CSV line
   * @returns {Array<string>} Array of values
   */
  parseCSVLine(line) {
    const values = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    values.push(current.trim());
    return values;
  }

  /**
   * Convert array of objects to CSV string
   * @param {Array<Object>} data - Array of objects
   * @returns {string} CSV string
   */
  toCSV(data) {
    if (!data || data.length === 0) {
      return '';
    }

    const headers = Object.keys(data[0]);
    const csvRows = [headers.join(',')];

    data.forEach(row => {
      const values = headers.map(header => {
        const value = row[header] || '';
        // Escape quotes and wrap in quotes if contains comma
        const stringValue = String(value);
        if (stringValue.includes(',') || stringValue.includes('"')) {
          return `"${stringValue.replace(/"/g, '""')}"`;
        }
        return stringValue;
      });
      csvRows.push(values.join(','));
    });

    return csvRows.join('\n');
  }

  /**
   * Extract emails from data based on column mapping
   * @param {Array<Object>} data - Array of data objects
   * @param {string} emailColumn - Name of email column
   * @returns {Array<Object>} Array with email and row index
   */
  extractEmails(data, emailColumn = 'email') {
    const emails = [];
    
    data.forEach((row, index) => {
      const email = row[emailColumn];
      if (email && typeof email === 'string' && email.includes('@')) {
        emails.push({
          email: email.trim(),
          rowIndex: index
        });
      }
    });

    return emails;
  }

  /**
   * Process CSV file and add email provider information
   * @param {string} inputFile - Path to input CSV file
   * @param {string} outputFile - Path to output CSV file
   * @param {Object} options - Processing options
   * @returns {Promise<Object>} Processing results
   */
  async processCSVFile(inputFile, outputFile, options = {}) {
    const emailColumn = options.emailColumn || 'email';
    const providerColumn = options.providerColumn || 'email_provider';
    
    try {
      console.log(`📖 Reading CSV file: ${inputFile}`);
      const csvContent = await fs.readFile(inputFile, 'utf-8');
      const data = this.parseCSV(csvContent);
      
      if (data.length === 0) {
        throw new Error('No data found in CSV file');
      }

      console.log(`📧 Found ${data.length} rows`);
      
      // Extract emails
      const emailData = this.extractEmails(data, emailColumn);
      console.log(`🔍 Processing ${emailData.length} emails:\n`);
      
      if (emailData.length === 0) {
        throw new Error(`No valid emails found in column '${emailColumn}'`);
      }

      // Detect providers
      const emails = emailData.map(item => item.email);
      const results = await detectEmailProviders(emails, this.concurrency, { showProgress: true });
      
      // Merge results back into original data
      const processedData = [...data];
      results.forEach((result, index) => {
        const rowIndex = emailData[index].rowIndex;
        processedData[rowIndex][providerColumn] = result.provider;
        
        // Optionally add more fields
        if (options.includeDetails) {
          processedData[rowIndex][`${providerColumn}_success`] = result.success;
          processedData[rowIndex][`${providerColumn}_domain`] = result.domain;
          if (!result.success && result.error) {
            processedData[rowIndex][`${providerColumn}_error`] = result.error;
          }
        }
      });

      // Handle output based on options
      if (options.separateByProvider) {
        // Create separate files by provider
        await this.saveResultsByProvider(results, outputFile);
      } else {
        // Ensure output directory exists
        await fs.mkdir(path.dirname(outputFile), { recursive: true });
        
        // Write processed CSV
        const outputCSV = this.toCSV(processedData);
        await fs.writeFile(outputFile, outputCSV);
        
        console.log(`✅ Processed CSV written to: ${outputFile}`);
      }
      
      // Generate statistics
      const stats = getProviderStats(results);
      
      // Write stats file if requested
      if (this.includeStats && !options.separateByProvider) {
        const statsFile = outputFile.replace('.csv', '_stats.json');
        await fs.writeFile(statsFile, JSON.stringify(stats, null, 2));
        console.log(`📊 Statistics written to: ${statsFile}`);
      }
      
      return {
        inputFile,
        outputFile,
        totalRows: data.length,
        emailsProcessed: results.length,
        stats
      };
      
    } catch (error) {
      console.error(`❌ Error processing CSV file: ${error.message}`);
      throw error;
    }
  }

  /**
   * Process JSON file and add email provider information
   * @param {string} inputFile - Path to input JSON file
   * @param {string} outputFile - Path to output JSON file
   * @param {Object} options - Processing options
   * @returns {Promise<Object>} Processing results
   */
  async processJSONFile(inputFile, outputFile, options = {}) {
    const emailField = options.emailField || 'email';
    const providerField = options.providerField || 'email_provider';
    
    try {
      console.log(`📖 Reading JSON file: ${inputFile}`);
      const jsonContent = await fs.readFile(inputFile, 'utf-8');
      let data = JSON.parse(jsonContent);
      
      // Handle both array and object formats
      if (!Array.isArray(data)) {
        if (data.records && Array.isArray(data.records)) {
          data = data.records;
        } else {
          throw new Error('JSON must be an array or have a "records" array property');
        }
      }
      
      if (data.length === 0) {
        throw new Error('No data found in JSON file');
      }

      console.log(`📧 Found ${data.length} records`);
      
      // Extract emails
      const emails = data
        .map((item, index) => ({ email: item[emailField], index }))
        .filter(item => item.email && typeof item.email === 'string' && item.email.includes('@'));
      
      console.log(`🔍 Processing ${emails.length} emails:\n`);
      
      if (emails.length === 0) {
        throw new Error(`No valid emails found in field '${emailField}'`);
      }

      // Detect providers
      const emailAddresses = emails.map(item => item.email);
      const results = await detectEmailProviders(emailAddresses, this.concurrency, { showProgress: true });
      
      // Merge results back into original data
      results.forEach((result, index) => {
        const dataIndex = emails[index].index;
        data[dataIndex][providerField] = result.provider;
        
        // Optionally add more fields
        if (options.includeDetails) {
          data[dataIndex][`${providerField}_success`] = result.success;
          data[dataIndex][`${providerField}_domain`] = result.domain;
          if (!result.success && result.error) {
            data[dataIndex][`${providerField}_error`] = result.error;
          }
        }
      });

      // Ensure output directory exists
      await fs.mkdir(path.dirname(outputFile), { recursive: true });
      
      // Write processed JSON
      await fs.writeFile(outputFile, JSON.stringify(data, null, 2));
      
      // Generate statistics
      const stats = getProviderStats(results);
      
      // Write stats file if requested
      if (this.includeStats) {
        const statsFile = outputFile.replace('.json', '_stats.json');
        await fs.writeFile(statsFile, JSON.stringify(stats, null, 2));
        console.log(`📊 Statistics written to: ${statsFile}`);
      }
      
      console.log(`✅ Processed JSON written to: ${outputFile}`);
      
      return {
        inputFile,
        outputFile,
        totalRecords: data.length,
        emailsProcessed: results.length,
        stats
      };
      
    } catch (error) {
      console.error(`❌ Error processing JSON file: ${error.message}`);
      throw error;
    }
  }

  /**
   * Process an array of email addresses and return results
   * @param {Array<string>} emails - Array of email addresses
   * @param {Object} options - Processing options
   * @returns {Promise<Object>} Processing results
   */
  async processEmailArray(emails, options = {}) {
    if (!Array.isArray(emails)) {
      throw new Error('Input must be an array of email addresses');
    }

    console.log(`🔍 Processing ${emails.length} emails:\n`);
    
    const results = await detectEmailProviders(emails, this.concurrency, { showProgress: true });
    const stats = getProviderStats(results);
    
    if (options.outputFile) {
      if (options.separateByProvider) {
        await this.saveResultsByProvider(results, options.outputFile);
      } else {
        const outputData = results.map(result => ({
          email: result.email,
          domain: result.domain,
          provider: result.provider,
          success: result.success,
          mxRecords: result.mxRecords?.join(', ') || '',
          error: result.error || ''
        }));
        
        await fs.mkdir(path.dirname(options.outputFile), { recursive: true });
        
        if (options.outputFile.endsWith('.json')) {
          await fs.writeFile(options.outputFile, JSON.stringify(outputData, null, 2));
        } else {
          const csvContent = this.toCSV(outputData);
          await fs.writeFile(options.outputFile, csvContent);
        }
        
        console.log(`✅ Results written to: ${options.outputFile}`);
      }
    }
    
    return {
      results,
      stats,
      totalEmails: emails.length,
      processedEmails: results.length
    };
  }

  /**
   * Save results grouped by provider in separate files
   * @param {Array} results - Detection results
   * @param {string} basePath - Base path for output (will be used as folder name)
   * @returns {Promise<void>}
   */
  async saveResultsByProvider(results, basePath) {
    // Create output folder
    const folderName = basePath.replace(/\.[^/.]+$/, '') + '_by_provider';
    await fs.mkdir(folderName, { recursive: true });
    
    // Group results by provider
    const groupedByProvider = {};
    const successfulResults = results.filter(r => r.success);
    const failedResults = results.filter(r => !r.success);
    
    // Group successful results by provider
    successfulResults.forEach(result => {
      const providerKey = this.sanitizeFilename(result.provider);
      if (!groupedByProvider[providerKey]) {
        groupedByProvider[providerKey] = {
          provider: result.provider,
          emails: []
        };
      }
      groupedByProvider[providerKey].emails.push(result.email);
    });
    
    // Save each provider's emails to separate files
    const savedFiles = [];
    for (const [providerKey, data] of Object.entries(groupedByProvider)) {
      const filename = `${providerKey.toLowerCase()}.txt`;
      const filepath = path.join(folderName, filename);
      const content = data.emails.join('\n');
      
      await fs.writeFile(filepath, content);
      savedFiles.push({
        provider: data.provider,
        filename: filename,
        count: data.emails.length
      });
    }
    
    // Save failed emails if any
    if (failedResults.length > 0) {
      const failedFilepath = path.join(folderName, 'failed.txt');
      const failedContent = failedResults.map(r => `${r.email} (${r.error})`).join('\n');
      await fs.writeFile(failedFilepath, failedContent);
      savedFiles.push({
        provider: 'Failed',
        filename: 'failed.txt',
        count: failedResults.length
      });
    }
    
    // Create summary file
    const summaryContent = [
      'Email Provider Detection Results Summary',
      '=' + '='.repeat(40),
      `Total emails processed: ${results.length}`,
      `Successful: ${successfulResults.length}`,
      `Failed: ${failedResults.length}`,
      '',
      'Files created:',
      ...savedFiles.map(file => `  ${file.filename} - ${file.provider} (${file.count} emails)`)
    ].join('\n');
    
    await fs.writeFile(path.join(folderName, 'summary.txt'), summaryContent);
    
    console.log(`\n📁 Results saved to folder: ${folderName}`);
    console.log('📄 Files created:');
    savedFiles.forEach(file => {
      console.log(`   ${file.filename} - ${file.count} emails (${file.provider})`);
    });
    console.log(`   summary.txt - Overview of all results`);
  }

  /**
   * Sanitize provider name for use as filename
   * @param {string} provider - Provider name
   * @returns {string} Sanitized filename
   */
  sanitizeFilename(provider) {
    return provider
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '_')
      .replace(/_{2,}/g, '_')
      .replace(/^_|_$/g, '');
  }

  /**
   * Filter results by provider
   * @param {Array} results - Detection results
   * @param {Array<string>} providers - Provider names to filter by
   * @returns {Array} Filtered results
   */
  filterByProvider(results, providers) {
    if (!Array.isArray(providers)) {
      providers = [providers];
    }
    
    return results.filter(result => 
      providers.some(provider => 
        result.provider.toLowerCase().includes(provider.toLowerCase())
      )
    );
  }

  /**
   * Generate a detailed report
   * @param {Array} results - Detection results
   * @returns {Object} Detailed report
   */
  generateReport(results) {
    const stats = getProviderStats(results);
    const successful = results.filter(r => r.success);
    const failed = results.filter(r => !r.success);
    
    const report = {
      summary: stats,
      topProviders: Object.entries(stats.providers)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 10)
        .map(([provider, count]) => ({
          provider,
          count,
          percentage: ((count / stats.successful) * 100).toFixed(1)
        })),
      failures: failed.map(r => ({
        email: r.email,
        error: r.error
      })),
      sampleResults: successful.slice(0, 5)
    };
    
    return report;
  }
} 